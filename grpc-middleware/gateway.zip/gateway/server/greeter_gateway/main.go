package main

import (
	"fmt"
	"log"
	"net/http"
	"time"

	gw "go-tip/gateway/server/helloworld"
	"os"

	"github.com/gorilla/handlers"
	gm "github.com/gorilla/mux"
	"github.com/grpc-ecosystem/grpc-gateway/runtime"
	"golang.org/x/net/context"
	"google.golang.org/grpc"
)

// middleware provides a convenient mechanism for filtering HTTP requests
// entering the application. It returns a new handler which performs various
// operations and finishes with calling the next HTTP handler.
type middleware func(http.HandlerFunc) http.HandlerFunc

// chainMiddleware provides syntactic sugar to create a new middleware
// which will be the result of chaining the ones received as parameters.
func chainMiddleware(mw ...middleware) middleware {
	return func(final http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			last := final
			for i := len(mw) - 1; i >= 0; i-- {
				last = mw[i](last)
			}
			last(w, r)
		}
	}
}

func withLogging(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		log.Printf("Logged connection from %s", r.RemoteAddr)
		next.ServeHTTP(w, r)
	}
}

func withTracing(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		log.Printf("Tracing request for %s", r.RequestURI)
		next.ServeHTTP(w, r)
	}
}

func final(w http.ResponseWriter, r *http.Request) {
	//w.Write([]byte("OK"))
	fmt.Printf("Hello World\n")
}

// Middleware that will store the http.Request into the Context
type gatewayMiddleware struct {
}

// the gatewayResponseModifier function needs the request object to
// be able to use gorilla's session stores correctly.  the only way to pass it on
// is through the context, so store it here
type xxxx string

func (middleware *gatewayMiddleware) Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		ctx := r.Context()
		if ctx == nil {
			ctx = context.Background()
		}
		var kkk xxxx
		kkk = "xxxxx"
		ctx = context.WithValue(ctx, kkk, r)

		fmt.Printf("hear.............\n")
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}
func (middleware *gatewayMiddleware) XMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		fmt.Printf("testtesttest.............\n")
		next.ServeHTTP(w, r)
	})
}
func (middleware *gatewayMiddleware) CORSMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		origin := r.Header.Get("Origin")
		w.Header().Set("Access-Control-Allow-Origin", origin)
		if r.Method == "OPTIONS" {
			w.Header().Set("Access-Control-Allow-Credentials", "true")
			w.Header().Set("Access-Control-Allow-Methods", "GET,POST")

			w.Header().Set("Access-Control-Allow-Headers", "Content-Type, X-CSRF-Token, Authorization")
			return
		} else {
			next.ServeHTTP(w, r)
		}
	})
}

func (middleware *gatewayMiddleware) LogMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		startTime := time.Now()
		next.ServeHTTP(w, r)
		endTime := time.Since(startTime)
		log.Printf("#### %s %d %v", r.URL, r.Method, endTime)
	})
}

func (middleware *gatewayMiddleware) RecoveryMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if err := recover(); err != nil {
				// respondInternalServerError
			}
		}()
		next.ServeHTTP(w, r)
	})
}

func CheckAuth(params string) bool {
	// TODO 할일이 많다는.
	return true
}

func (middleware *gatewayMiddleware) AuthMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		params := r.URL.RawQuery
		// TODO 인증로직을 더 짜야한다는.......
		if CheckAuth(params) {
			log.Println("Auth Pass")
			// pass control to next middleware in chain or handler func
			next.ServeHTTP(w, r)
		} else {
			log.Println("Auth Fail")
			// Responsd Auth Fail
		}
	})
}

func main() {
	//mw := chainMiddleware(withLogging, withTracing)
	mux := runtime.NewServeMux()
	if err := gw.RegisterGreeterHandlerFromEndpoint(context.Background(), mux, "localhost:50051", []grpc.DialOption{grpc.WithInsecure()}); err != nil {
		log.Fatal(err)
	}
	log.Printf("running gateway...")

	loggingHandler := handlers.CombinedLoggingHandler(os.Stderr, mux)

	grouter := gm.NewRouter()
	middleware := gatewayMiddleware{}
	grouter.Use(middleware.Middleware, middleware.XMiddleware, middleware.LogMiddleware, middleware.CORSMiddleware)

	grouter.PathPrefix("/").Handler(loggingHandler)

	srv := &http.Server{
		Addr: ":9123",

		WriteTimeout: time.Second * 15,
		ReadTimeout:  time.Second * 15,
		IdleTimeout:  time.Second * 60,

		Handler: grouter,
	}
	if err := srv.ListenAndServe(); err != nil {
		log.Fatal(err)
	}
}

// test
// https://stackoverflow.com/questions/12173990/how-can-you-debug-a-cors-request-with-curl
// curl -H "Origin: http://example.com"   -H "Access-Control-Request-Method: POST"   -H "Access-Control-Request-Headers: X-Requested-With"   -X OPTIONS --verbose --verbose http://localhost:9123/v1/helloworld/sayhello -H "Content-Type: text/plain" -d '{"name": "old school"}'; echo
